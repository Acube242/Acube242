<h3>&quot;I wonder if rooms in an insane asylum have Do Not Disturb signs for the doors. I should hope not, because knock or no knock, every occupant in those rooms is already disturbed.&quot; </h3>
