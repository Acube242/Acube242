
<table cellpadding="5" cellspacing="0">
  <tr>
    <td><center>
      <?php include ("search_form.php");?>
    </center></td>
  </tr>
  <tr>
    <td><h2>
      <center>
        RECENTLY ADDED BOOKS
      </center>
    </h2></td>
  </tr>
  <tr>
    <td><?php include ("new_addition.php");?></td>
  </tr>
</table>

