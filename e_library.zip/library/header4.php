<h3>“For I, who hold sage Homer's rule the best,    Welcome the coming, speed the going guest.”  			  		</h3>
