<h3>&ldquo;Whenever you go on a trip to visit foreign lands or distant places, remember that they are all someone's home and backyard.&rdquo;    </h3>
