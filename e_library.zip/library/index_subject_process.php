<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Library, Ghalib Chambers (Law Firm), Ilorin, Nigeria</title>
<meta name="description" content="Yusuf Ali &amp; Co., Ghalib Chambers (Law Firm), Ilorin, Nigeria.  came into existence 
                                  and started out on 1st June, 1994." />
<meta name="keywords" content="Ghalib Chambers, Yusuf Ali & Co,legal firms,law Sites,law firms in Nigeria, Litigation, Dispute, Nigerian Bar Association, BAR, Real Estate, Tax Advisory Services, Shipping, Nigeria,ilorin, kwara, Nigerian lawyers,corporate firms in Nigeria, Business laws, legal resources, law articles, law publications, law links, lagos,  Abuja, chambers " />

<meta name="verify-v1" content="zDEbGNy2UDWyQimwLoOkZPEwGgTDqmfzxr6okFS1rrQ=" />
    <script language="javascript" src="subject.js"></script>
<style type="text/css">
<!--

-->
</style>
    <link href="../taofikabdulkareem.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0" background="../images/bg.jpg">
  <tr>
    <td bgcolor="#005875" style="border-bottom:#FFFFFF 3px solid;"><table width="1104" border="0" align="center" cellpadding="2" cellspacing="0" style="height:50px;">
      <tr align="center" valign="middle">
        <td width="88" class="cell"><a name="top" id="top"></a><a href="../index.htm" class="top">HOME</a></td>
        <td width="88" class="cell"><a href="../firm.htm" class="top">THE FIRM </a></td>
        <td width="88" class="cell"><a href="../team.htm" class="top">OUR TEAM </a></td>
        <td width="88" class="cell"><a href="../offices.htm" class="top">OFFICES</a></td>
        <td width="88" nowrap="nowrap" class="cell"><a href="../practice.htm" class="top">LEGAL SERVICES </a></td>
        <td width="88" class="cell"><a href="../clients.htm" class="top">CLIENTS</a></td>
        <td width="88" class="cell"><a href="../publications.htm" class="top">PUBLICATIONS</a></td>
        <td width="88" bgcolor="#8BE6ED" class="cell"><a href="index.php" class="top">LIBRARY</a></td>
        <td width="88" nowrap="nowrap" class="cell"><a href="../reported-cases/works.htm" class="top">REPORTED CASES </a></td>
        <td width="88" class="cell"><a href="../resources.htm" class="top">RESOURCES</a></td>
        <td width="88" class="cell"><a href="../contact.htm" class="top"></a><a href="../news_archives/index.php" class="top">NEWS</a></td>
        <td width="88" class="cell"><a href="../contact.htm" class="top">CONTACT US</a></td>
        <td width="88" class="cell"><a href="http://www.yusufali.net/email" target="_blank" class="top">EMAIL</a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td><a href="http://www.yusufali.net"><img src="../images/banner.jpg" alt="Yusuf Ali &amp; Co., Ghalib Chambers (Law Firm), Ilorin, Nigeria., Ilorin, Nigeria; Legal Practitioners; A firm of Nigerian lawyers based in Ilorin" width="800" height="361" border="0" align="absmiddle" /></a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><table width="800" border="0" align="center" cellpadding="8" cellspacing="0">
      <tr>
        <td align="left" valign="top" bgcolor="#B5F2FD" style="border-bottom:4px solid #FFFFFF; border-top:4px solid #003399;"><h1>Welcome 
                                    to Yusuf Ali &amp; Co., Ghalib Chamber's Library Ilorin, Nigeria. </h1>
          <p align="right"><a href="javascript:history.go(-1)">previous page</a> ||<a href="http://www.facebook.com/sharer.php" name="fb_share" id="fb_share" type="button_count">Share on Facebook </a>
            <script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script>
          </p>          </td>
        </tr>
      <tr>
        <td align="left" valign="top" nowrap="nowrap" bgcolor="#C6E2FF" style="border-top:4px solid #003366; border-right:solid 3px #FFFFFF; border-bottom:#FFFFFF solid 4px"><table width="99%" border="0" align="center">
  <tr>
    <td width="31%" align="left" valign="top" nowrap><p>
      <?php include ("index_subject2.php");?> 
    <strong>OR</strong></p></td><td width="69%" align="right" valign="top"><?php include ("search_form.php");?></td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top"><div id="txtAuthor"><?php include ("index_subject_process2.php") ?></div></td>
    </tr>
  
</table>
          </td>
        </tr>
      
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#005875"><table width="800" height="20" border="0" align="center" cellpadding="4" cellspacing="0" bgcolor="#FFFFFF" style="border-top:3px solid #005875">
      <tr>
        <td>&nbsp;Copyright &copy; 2006-2011 Yusuf Ali &amp; Co., Ghalib Chambers.<sup>&reg;</sup> All rights reserved.</td>
        <td nowrap="nowrap" class="footer"><a href="#top">Back to top</a></td>
        <td nowrap="nowrap" class="footer"><div align="right"><a href="http://www.platgroupng.com" target="_blank">Website designed by Plat</a>&nbsp;&nbsp;</div></td>
      </tr>
    </table></td>
  </tr>
</table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1290416-8");
pageTracker._trackPageview();
} catch(err) {}</script></body>
</html>
