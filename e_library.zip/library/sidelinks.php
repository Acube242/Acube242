<p class="heading">Quick Links</p>
<ul>
<li><a href='borrow.php' >Borrow Book</a></li>
<li><a href='return.php' >Return Book</a></li>
<li><a href='view.php' >View All</a></li>
</ul>
