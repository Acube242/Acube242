<p class="heading">Quick Links</p>
<ul>
<li><a href="add_book.php">ADD BOOKS</a></li>
<li><a href="edit.php">EDIT BOOK DETAILS </a></li>
<li><a href="user.php">ADD USER</a></li>
<li><a href="../search_form2.php">SEARCH</a></li>
<li><a href="book_option.php">VIEW LIST</a></li>
<li><a href="exit.php">LOGOUT</a></li>
</ul>