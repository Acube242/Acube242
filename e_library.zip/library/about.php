<?php session_start();?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Library Management System</title>
<script language="javascript" type="text/javascript" src="include/calendar.js"></script>
<script language="javascript" type="text/javascript" src="include/config.js"></script>
<script language="javascript" type="text/javascript" src="include/submit.js"></script>
<script language="javascript" type="text/javascript" src="include/nav_functions.js"></script>
<script src="include/urchin.js" type="text/javascript"></script>
<script type="text/javascript" src="include/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="include/jquery.tools.js"></script>	
<script type="text/javascript" src="include/jquery.custom.js"></script>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<div class="wrapper">
<?php include("top.php");?>  
  <!-- Main wrapper div starts here-->
  <div class="main_wrapper">
  
  <!-- Content wrapper div starts here-->
    <div class="content_wrapper">
    <h1>About</h1>
<p>Warning: This Distributed system    for central exchange of student records in tertiary institution program is protected by copyright law and international treaties. Unathorized reproduction or distribution of this program, or any portion of it, may result in severe civil and criminal penalties, and will be prosecuted to the maximum extent possible under law.
</p>
<p>Developed by: Idayat In Award of HND In Computer Sience Kwara State Polytechnic 2013</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
    <!-- Content wrapper div ends here-->
    
    <!-- Right wrapper div starts here-->
      <div id="side_bar">
        <?php //include('sidelinks.php'); ?>
      </div>
    <!-- Right wrapper div ends here-->
                  <div class="clr"></div>
        <div><img src="images/edge_bottom.jpg" border="0" /></div>
  </div>
  <p>

  <!-- Main wrapper div ends here-->
</div>
</body>

</html>
